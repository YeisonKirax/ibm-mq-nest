export const IBM_MQ_HANDLER = Symbol('IBM_MQ_HANDLER');
export const IBM_MQ_CONFIG_TOKEN = Symbol('IBM_MQ_CONFIG');
export const IBM_MQ_ARGS_METADATA = 'IBM_MQ_ARGS_METADATA';
export const IBM_MQ_PARAM_TYPE = 3;
export const IBM_MQ_HEADER_TYPE = 4;
export const IBM_MQ_REQUEST_TYPE = 5;
